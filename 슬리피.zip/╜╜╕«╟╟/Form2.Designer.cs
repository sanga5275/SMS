﻿namespace Sleep_Monitoring_System
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label1 = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.cb1 = new System.Windows.Forms.CheckBox();
            this.cb2 = new System.Windows.Forms.CheckBox();
            this.cb3 = new System.Windows.Forms.CheckBox();
            this.cb4 = new System.Windows.Forms.CheckBox();
            this.cb5 = new System.Windows.Forms.CheckBox();
            this.cb6 = new System.Windows.Forms.CheckBox();
            this.cb7 = new System.Windows.Forms.CheckBox();
            this.cb8 = new System.Windows.Forms.CheckBox();
            this.cb9 = new System.Windows.Forms.CheckBox();
            this.cb10 = new System.Windows.Forms.CheckBox();
            this.btnResult = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("배달의민족 주아", 22F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(77, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(400, 48);
            this.label1.TabIndex = 0;
            this.label1.Text = "불면증 자가진단 테스트";
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Location = new System.Drawing.Point(347, 13);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(0, 18);
            this.lblTimer.TabIndex = 1;
            // 
            // cb1
            // 
            this.cb1.AutoSize = true;
            this.cb1.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cb1.Location = new System.Drawing.Point(29, 147);
            this.cb1.Name = "cb1";
            this.cb1.Size = new System.Drawing.Size(319, 22);
            this.cb1.TabIndex = 3;
            this.cb1.Text = "잠에 들기까지 30분 이상 걸린다.";
            this.cb1.UseVisualStyleBackColor = true;
            // 
            // cb2
            // 
            this.cb2.AutoSize = true;
            this.cb2.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cb2.Location = new System.Drawing.Point(29, 190);
            this.cb2.Name = "cb2";
            this.cb2.Size = new System.Drawing.Size(297, 22);
            this.cb2.TabIndex = 4;
            this.cb2.Text = "잠을 잘 자기 위해서 노력한다.";
            this.cb2.UseVisualStyleBackColor = true;
            // 
            // cb3
            // 
            this.cb3.AutoSize = true;
            this.cb3.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cb3.Location = new System.Drawing.Point(29, 218);
            this.cb3.Name = "cb3";
            this.cb3.Size = new System.Drawing.Size(354, 40);
            this.cb3.TabIndex = 5;
            this.cb3.Text = "잠들기 위해 술을 마시거나, 약국에서\r\n수면제를 사서 먹어본 적이 있다.\r\n";
            this.cb3.UseVisualStyleBackColor = true;
            // 
            // cb4
            // 
            this.cb4.AutoSize = true;
            this.cb4.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cb4.Location = new System.Drawing.Point(29, 262);
            this.cb4.Name = "cb4";
            this.cb4.Size = new System.Drawing.Size(297, 22);
            this.cb4.TabIndex = 6;
            this.cb4.Text = "휴일에는 실컷 자는 수가 있다.\r\n";
            this.cb4.UseVisualStyleBackColor = true;
            // 
            // cb5
            // 
            this.cb5.AutoSize = true;
            this.cb5.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cb5.Location = new System.Drawing.Point(29, 303);
            this.cb5.Name = "cb5";
            this.cb5.Size = new System.Drawing.Size(380, 22);
            this.cb5.TabIndex = 7;
            this.cb5.Text = "잠자리가 바뀌면 잠을 오히려 더 잘잔다.";
            this.cb5.UseVisualStyleBackColor = true;
            // 
            // cb6
            // 
            this.cb6.AutoSize = true;
            this.cb6.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cb6.Location = new System.Drawing.Point(29, 346);
            this.cb6.Name = "cb6";
            this.cb6.Size = new System.Drawing.Size(548, 22);
            this.cb6.TabIndex = 8;
            this.cb6.Text = "자는 도중에 두 세 차례 이상 잠을 깨고 다시 잠들기 어렵다.\r\n";
            this.cb6.UseVisualStyleBackColor = true;
            // 
            // cb7
            // 
            this.cb7.AutoSize = true;
            this.cb7.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cb7.Location = new System.Drawing.Point(29, 387);
            this.cb7.Name = "cb7";
            this.cb7.Size = new System.Drawing.Size(591, 22);
            this.cb7.TabIndex = 9;
            this.cb7.Text = "자다가 중간에 깨면 얼마나 잤는지를 확인하기 위해 시계를 본다.\r\n";
            this.cb7.UseVisualStyleBackColor = true;
            // 
            // cb8
            // 
            this.cb8.AutoSize = true;
            this.cb8.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cb8.Location = new System.Drawing.Point(29, 433);
            this.cb8.Name = "cb8";
            this.cb8.Size = new System.Drawing.Size(591, 22);
            this.cb8.TabIndex = 10;
            this.cb8.Text = "낮에 항상 졸리고 특히 점심식후에는 정신이 없을 정도로 졸리다.";
            this.cb8.UseVisualStyleBackColor = true;
            // 
            // cb9
            // 
            this.cb9.AutoSize = true;
            this.cb9.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cb9.Location = new System.Drawing.Point(29, 478);
            this.cb9.Name = "cb9";
            this.cb9.Size = new System.Drawing.Size(522, 22);
            this.cb9.TabIndex = 11;
            this.cb9.Text = "항상 많은 꿈을 꾸고, 깨고 나서도 대개는 기억이 안난다.";
            this.cb9.UseVisualStyleBackColor = true;
            // 
            // cb10
            // 
            this.cb10.AutoSize = true;
            this.cb10.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cb10.Location = new System.Drawing.Point(29, 521);
            this.cb10.Name = "cb10";
            this.cb10.Size = new System.Drawing.Size(451, 22);
            this.cb10.TabIndex = 12;
            this.cb10.Text = "평소보다 훨씬 일찍 깨면 더 이상 잠들기 어렵다.";
            this.cb10.UseVisualStyleBackColor = true;
            // 
            // btnResult
            // 
            this.btnResult.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnResult.Location = new System.Drawing.Point(29, 584);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(107, 34);
            this.btnResult.TabIndex = 13;
            this.btnResult.Text = "제출";
            this.btnResult.UseVisualStyleBackColor = true;
            this.btnResult.Click += new System.EventHandler(this.btnResult_Click);
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnNext.Location = new System.Drawing.Point(486, 584);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(107, 34);
            this.btnNext.TabIndex = 14;
            this.btnNext.Text = "다음";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(12, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(174, 25);
            this.label3.TabIndex = 15;
            this.label3.Text = "당신의 더 좋은 수면";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(483, 34);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(90, 93);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(636, 644);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnResult);
            this.Controls.Add(this.cb10);
            this.Controls.Add(this.cb9);
            this.Controls.Add(this.cb8);
            this.Controls.Add(this.cb7);
            this.Controls.Add(this.cb6);
            this.Controls.Add(this.cb5);
            this.Controls.Add(this.cb4);
            this.Controls.Add(this.cb3);
            this.Controls.Add(this.cb2);
            this.Controls.Add(this.cb1);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Sleep Monitoring System";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.CheckBox cb1;
        private System.Windows.Forms.CheckBox cb2;
        private System.Windows.Forms.CheckBox cb3;
        private System.Windows.Forms.CheckBox cb4;
        private System.Windows.Forms.CheckBox cb5;
        private System.Windows.Forms.CheckBox cb6;
        private System.Windows.Forms.CheckBox cb7;
        private System.Windows.Forms.CheckBox cb8;
        private System.Windows.Forms.CheckBox cb9;
        private System.Windows.Forms.CheckBox cb10;
        private System.Windows.Forms.Button btnResult;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
    }
}